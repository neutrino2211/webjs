export class TemplateApplication{
    constructor(){
        console.log("Ready")
    }

    main(){
        $("body").append(this.template)
        document.dispatchEvent(new Event("__INIT__"))
        // window.WJS_PAGE_STATE = 1;
    }
}

export class TemplateApplicationPage{
    /**
     * 
     * @param {HTMLElement} element 
     */
    constructor(element){
        this.element = element;
        if(window.openPage){
            window.openPage.close()
        }
        window.openPage = this;
        console.log("page created")
    }
    close(){
        this.isClosed = true;
        this.element.innerHTML = ""
    }
}