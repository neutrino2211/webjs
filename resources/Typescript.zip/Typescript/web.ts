export const $ = window.jQuery;

export function print(...args: any[]){
    document.write(...args);
}